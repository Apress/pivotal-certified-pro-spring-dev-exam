package com.ps.services;

import com.ps.ents.Request;
import com.ps.ents.Response;
import com.ps.ents.User;

/**
 * Created by iuliana.cosmina on 2/22/16.
 */
public interface ResponseService {

}
