package com.ps.services;

import com.ps.ents.User;

/**
 * Created by iuliana.cosmina on 7/16/16.
 */
public interface PetService {

    String getPetsAsHtml(User owner);
}
