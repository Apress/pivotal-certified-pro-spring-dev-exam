package com.ps.tmp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by iuliana.cosmina on 3/21/16.
 */
@Configuration
@ComponentScan(basePackages = "com.ps.tmp")
public class AppConfig {

}
