package com.ps.services;

import com.ps.ents.Response;

/**
 * Created by iuliana.cosmina on 2/22/16.
 */
public interface ResponseService extends AbstractService<Response> {

}
