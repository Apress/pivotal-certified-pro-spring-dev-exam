package com.ps.cfg;

import org.springframework.context.annotation.Configuration;

/**
 * Created by iuliana.cosmina on 11/18/16.
 */
@Configuration
public class Appconfig {
}
