package com.ps.exceptions;

/**
 * Created by iuliana.cosmina on 7/17/16.
 */
public class MailSendingException extends Exception{
    public MailSendingException(String message) {
        super(message);
    }
}
