package com.ps.sample;

import org.springframework.stereotype.Component;

/**
 * Created by iuliana.cosmina on 5/2/16.
 */
@Component
public class TestBeanOne {
}
