/**
 * Created by iuliana.cosmina on 3/26/16.
 * Contains classes used to create Spring beans using setter injection.
 */
package com.ps.beans.set;