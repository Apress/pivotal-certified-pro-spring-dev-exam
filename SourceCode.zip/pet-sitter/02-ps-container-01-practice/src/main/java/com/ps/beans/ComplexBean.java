package com.ps.beans;

/**
 * Created by iuliana.cosmina on 3/26/16.
 */
public interface ComplexBean {
}
