INSERT INTO P_USER(ID, USERNAME, PASSWORD, EMAIL) VALUES (1, 'John', 'test', 'john@pet.com');
INSERT INTO P_USER(ID, USERNAME, PASSWORD, EMAIL) VALUES (2, 'Mary', 'test', 'mary@pet.com');
INSERT INTO P_USER(ID, USERNAME, PASSWORD, EMAIL) VALUES (3, 'Victoria', 'test', 'victoria@pet.com');
INSERT INTO P_USER(ID, USERNAME, PASSWORD, EMAIL) VALUES (4, 'Johnny', 'test', 'johnny@pet.com');