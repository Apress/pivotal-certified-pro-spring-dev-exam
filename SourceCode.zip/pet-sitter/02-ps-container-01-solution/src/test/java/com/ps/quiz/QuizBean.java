package com.ps.quiz;

import org.springframework.stereotype.Component;

/**
 * Created by iuliana.cosmina on 11/18/16.
 */
@Component
public class QuizBean {
}
