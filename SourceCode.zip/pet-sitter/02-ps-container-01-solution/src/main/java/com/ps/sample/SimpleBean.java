package com.ps.sample;

/**
 * Created by iuliana.cosmina on 3/28/16.
 */
public class SimpleBean {
}
